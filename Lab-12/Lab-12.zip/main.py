from green_beans import GreenBeans
from large_plate import LargePlate
from pie import Pie
from potatoes import Potatoes
from small_plate import SmallPlate
from stuffing import Stuffing
from turkey import Turkey
from check_input import get_int_range

def examine_plate(p):

def main():
    print("-Thanksgiving Dinner- \nServe yourself as much food as you like from the buffet, but make sure that your plate will hold without spilling everywhere! \nChoose a plate!:")
    print("1. Small Sturdy Plate")
    print("2. Large Flimsy Plate")

    plate_choice = get_int_range("", 1, 2)

if __name__ == "__main__":
    main()
